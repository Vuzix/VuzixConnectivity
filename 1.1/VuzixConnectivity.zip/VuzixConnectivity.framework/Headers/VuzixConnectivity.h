//
//  Connectivity.h
//  Connectivity
//
//  Created by Joe Martin on 5/13/19.
//  Copyright © 2019 Vuzix. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Connectivity.
FOUNDATION_EXPORT double ConnectivityVersionNumber;

//! Project version string for Connectivity.
FOUNDATION_EXPORT const unsigned char ConnectivityVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Connectivity/PublicHeader.h>

#import <CommonCrypto/CommonCryptor.h>
